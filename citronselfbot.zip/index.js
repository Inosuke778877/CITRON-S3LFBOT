const { Client } = require('discord.js-selfbot-v13');
const fs = require('fs');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();
const express = require('express');
const config = require('./config.json');
const { handleGroq } = require('./ai/groq');
const { handleGemini } = require('./ai/gemini');

const client = new Client({ checkUpdate: false });
const app = express();

// Load configurations
const aiConfig = require('./ai-config.json');
const rpcConfig = require('./rpc-config.json');

// Database setup
const db = new sqlite3.Database('./database.db', (err) => {
    if (err) console.error('Database error:', err);
});

// Create AI settings table
db.run(`
    CREATE TABLE IF NOT EXISTS ai_settings (
        channel_id TEXT PRIMARY KEY,
        ai_enabled BOOLEAN
    )
`);

// Command handler
const commands = new Map();
const commandFiles = fs.readdirSync('./commands').filter(file => file.endsWith('.js'));

(async () => {
    for (const file of commandFiles) {
        const command = require(`./commands/${file}`);
        commands.set(command.name, command);
    }
})();

// AI response customization
const knowledge = require('./knowledge.js');

// Web dashboard setup
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'dashboard/views'));
app.use(express.static(path.join(__dirname, 'dashboard/public')));
app.use(express.json());

app.get('/', (req, res) => {
    res.render('index', { botStatus: client.isReady(), username: client.user?.username || 'Offline' });
});

app.get('/commands', (req, res) => {
    res.render('commands', { commands: Array.from(commands.values()) });
});

app.post('/toggle-ai/:channelId', async (req, res) => {
    const { channelId } = req.params;
    const { enabled } = req.body;
    db.run(
        `INSERT OR REPLACE INTO ai_settings (channel_id, ai_enabled) VALUES (?, ?)`,
        [channelId, enabled],
        (err) => {
            if (err) return res.status(500).json({ error: 'Database error' });
            res.json({ success: true });
        }
    );
});

app.listen(config.port, () => {
    console.log(`Web dashboard running on http://localhost:${config.port}`);
});

// Discord client events
client.on('ready', () => {
    if (rpcConfig.enabled) {
        client.user.setPresence({
            activities: [{
                name: rpcConfig.largeText,
                type: 'PLAYING',
                largeImageKey: rpcConfig.imageLink
            }],
            status: 'online'
        });
    }
});

client.on('messageCreate', async (message) => {
    if (!config.allowedUserIds.includes(message.author.id)) return;
    
    // Check if message is a command
    if (message.content.startsWith(config.prefix)) {
        const args = message.content.slice(config.prefix.length).trim().split(/ +/);
        const commandName = args.shift().toLowerCase();
        const command = commands.get(commandName);
        
        if (command) {
            try {
                await command.execute(message, args, client);
            } catch (error) {
                console.error(`Error executing command ${commandName}:`, error);
                await message.channel.send('Error executing command.');
            }
        }
        return;
    }

    // AI response handling
    db.get(
        `SELECT ai_enabled FROM ai_settings WHERE channel_id = ?`,
        [message.channel.id],
        async (err, row) => {
            if (err) {
                console.error('Database error:', err);
                return;
            }
            
            if (row?.ai_enabled && message.author.id !== client.user.id) {
                try {
                    let response;
                    
                    // Check if message contains images
                    if (message.attachments.size > 0) {
                        response = await handleGemini(message, aiConfig, knowledge);
                    } else {
                        response = await handleGroq(message, aiConfig, knowledge);
                    }
                    
                    await message.channel.send(response);
                } catch (error) {
                    console.error('AI response error:', error);
                    await message.channel.send('Error processing AI response.');
                }
            }
        }
    );
});

client.login(config.token);