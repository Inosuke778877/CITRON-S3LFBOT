module.exports = {
    textPrompt: "You are a helpful AI assistant with a friendly tone. Provide concise and accurate responses based on the user's input.",
    imagePrompt: "Describe the image in detail and provide a relevant response to any accompanying text."
};