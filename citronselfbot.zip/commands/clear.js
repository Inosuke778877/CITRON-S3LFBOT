module.exports = {

  name: 'clear',

  description: 'Clears the bot\'s own messages in the channel. Usage: !clear',

  async execute(message, args, client) {

    try {

      // Fetch messages in the channel

      const messages = await message.channel.messages.fetch({ limit: 100 });

      

      // Filter messages sent by the bot

      const botMessages = messages.filter(msg => msg.author.id === client.user.id);

      

      if (botMessages.size === 0) {

        return message.reply('🧹 No messages from me to clear.');

      }

      // Delete each bot message

      for (const msg of botMessages.values()) {

        await msg.delete();

        await new Promise(resolve => setTimeout(resolve, 500)); // Delay to avoid rate limits

      }

      await message.reply(`🧹 Cleared ${botMessages.size} of my messages.`);

    } catch (error) {

      await message.reply(`❌ Error clearing messages: ${error.message}`);

    }

  }

};