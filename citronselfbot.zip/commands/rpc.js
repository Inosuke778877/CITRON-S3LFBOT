const fs = require('fs').promises;
const path = require('path');

module.exports = {
    name: 'rpc',
    description: 'Set or toggle RPC status',
    async execute(message, args, client) {
        if (args.length < 2) {
            return message.channel.send('Usage: !rpc {on/off} {large text} [image link]');
        }

        const [status, ...textArgs] = args;
        const largeText = textArgs.join(' ');
        const imageLink = args.find(arg => arg.startsWith('https://cdn.discordapp.com'));

        const rpcConfigPath = path.join(__dirname, '../rpc-config.json');
        let rpcConfig = require(rpcConfigPath);

        if (status.toLowerCase() === 'on') {
            rpcConfig.enabled = true;
            rpcConfig.largeText = largeText;
            if (imageLink) rpcConfig.imageLink = imageLink;

            await fs.writeFile(rpcConfigPath, JSON.stringify(rpcConfig, null, 2));
            
            client.user.setPresence({
                activities: [{
                    name: largeText,
                    type: 'PLAYING',
                    largeImageKey: imageLink || rpcConfig.imageLink
                }],
                status: 'online'
            });
            
            return message.channel.send('RPC enabled with specified settings.');
        } else if (status.toLowerCase() === 'off') {
            rpcConfig.enabled = false;
            await fs.writeFile(rpcConfigPath, JSON.stringify(rpcConfig, null, 2));
            client.user.setPresence({ status: 'online' });
            return message.channel.send('RPC disabled.');
        } else {
            return message.channel.send('Invalid status. Use "on" or "off".');
        }
    }
};