const fs = require('fs').promises;
const path = require('path');

module.exports = {
    name: 'help',
    description: 'Display all available commands',
    async execute(message, args, client) {
        try {
            const commandFiles = await fs.readdir(path.join(__dirname));
            const commands = [];
            
            for (const file of commandFiles) {
                if (file.endsWith('.js')) {
                    const command = require(path.join(__dirname, file));
                    commands.push({ name: command.name, description: command.description });
                }
            }

            const commandList = commands
                .map(cmd => `!${cmd.name}: ${cmd.description}`)
                .join('\n');
            
            const response = '```js\n' + commandList + '\n```\n```html\n🤖 Made by INOSUKE_ON_DRUGXXX```';

            await message.channel.send(response);
        } catch (error) {
            console.error('Help command error:', error);
            await message.channel.send('Error retrieving command list.');
        }
    }
};