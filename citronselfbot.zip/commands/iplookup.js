const axios = require('axios');

module.exports = {

  name: 'iplookup',

  description: 'Looks up details for an IP address. Usage: !iplookup <ip>',

  async execute(message, args, client) {

    if (!args[0]) {

      return message.reply('Please provide an IP address (e.g., 8.8.8.8).');

    }

    const ip = args[0];

    try {

      const response = await axios.get(`http://ip-api.com/json/${ip}`);

      if (response.data.status === 'fail') {

        return message.reply('Invalid IP address.');

      }

      const { query, country, city, isp, org } = response.data;

      await message.reply(

        `IP: ${query}\n` +

        `Country: ${country}\n` +

        `City: ${city}\n` +

        `ISP: ${isp}\n` +

        `Organization: ${org || 'N/A'}`

      );

    } catch (error) {

      await message.reply('Failed to lookup IP address. Please try again.');

    }

  }

};